# Prompt Generator

Use this app to generate prompts based on task, funnel stage, and automation level. Built with Next.js + Tailwind.